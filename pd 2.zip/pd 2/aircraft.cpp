#include <iostream>
using namespace std;
main()
{
    cout<<"            /\\                \n";
    cout<<"           /  \\               \n";
    cout<<"       ___/ ~~ \\___             \n";
    cout<<"      /    |  |    \\            \n";
    cout<<"     ======.  .======             \n";
    cout<<"         | | | |                  \n";
}

