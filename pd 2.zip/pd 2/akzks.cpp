#include<iostream>
using namespace std;
main()
{
    cout<<"              ####                       \n";
    cout<<"             ##  ##                      \n";
    cout<<"             ######                        \n";
    cout<<"             ##  ##                      \n";
    cout<<"             ##  ##                      \n";
    cout<<"             ##  ##                      \n";
    cout<<"                                   \n";
    cout<<"             ##  ##                          \n";
    cout<<"             ##  ##                         \n";
    cout<<"             ####                        \n";
    cout<<"             ##                        \n";
    cout<<"             ####                        \n";
    cout<<"             ##  ##                      \n";
    cout<<"             ##  ##                      \n";
    cout<<"                                   \n";
    cout<<"             ######                       \n";
    cout<<"                 ##                    \n";
    cout<<"                ##                     \n";
    cout<<"               ##                      \n";
    cout<<"              ##                       \n";
    cout<<"             ######                        \n";
    cout<<"                                   \n";
    cout<<"             ##  ##                          \n";
    cout<<"             ##  ##                         \n";
    cout<<"             ####                        \n";
    cout<<"             ##                        \n";
    cout<<"             ####                        \n";
    cout<<"             ##  ##                      \n";
    cout<<"             ##  ## \n";
    cout<<"                                    \n";
    cout<<"              ####                         \n";
    cout<<"             ##  ##                      \n";
    cout<<"             ##                        \n";
    cout<<"              ####                       \n";
    cout<<"                 ##                    \n";
    cout<<"             ##  ##                    \n";
    cout<<"              ####                       \n";
}