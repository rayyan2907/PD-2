#include<iostream>
using namespace std;
main()
{
    cout<<"  ' ;_.           ----'                                            \n";
    cout<<"     '.'!_...._/'._''        ,                                           \n";
    cout<<"        !        /          , ,-                                      \n";
    cout<<"        / () () !          .    ._                               \n";
    cout<<"       |)  .   ()!       /     -.'                                      \n";
    cout<<"        |  _'_        ,;  '.   <                                 \n";
    cout<<"        ;.--       ,; |    >   |                                  \n";
    cout<<"       / ,     / ,    | .-'  ._'                                        \n";
    cout<<"      (_/     (_/   .;|.<'                                          \n";
    cout<<"        !    ,        ;-'                                   \n";
    cout<<"         >   !       /                                 \n";
    cout<<"        (_,_''>   . '                                              \n";
    cout<<"            (_,'                                             \n";
    
}
