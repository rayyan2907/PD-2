#include<iostream>
using namespace std;
main()
{
    system("color 46 ");
    cout << "This is my text";
}