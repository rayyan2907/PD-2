#include<iostream>
using namespace std;
main()
{
    cout<<"-------------------------------------                                             \n";
    cout<<"                                             \n";
    cout<<"     o      ^__^                                  \n";
    cout<<"            (oo)\\____________                                \n";
    cout<<"            (__)\\           )\\/\\                                  \n";
    cout<<"                ||    ----W  |                           \n";
    cout<<"                ||          s||                   \n";
    cout<<"                                             \n";
    cout<<"                                             \n";
}
    