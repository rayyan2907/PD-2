#include<iostream>
using namespace std;
main()
{
    cout<<"          *           *         *                            \n";
    cout<<"            *          *         *                           \n";
    cout<<"             *          *         *                        \n";
    cout<<"            *          *         *                         \n";
    cout<<"           *          *         *                           \n";
    cout<<"            *          *         *                           \n";
    cout<<"             *          *         *                           \n";
    cout<<" ***********************************************                                                         \n";
    cout<<"   *                                          *                                                       \n";
    cout<<"     *                                      *                                                      \n";
    cout<<"       *                                  *                             \n";
    cout<<"         *                              *        \n";
    cout<<"           ****************************                   \n";
    cout<<"                                                          \n";
    cout<<"        #WELCOME TO THE FOODY APPLICATION#                                                     \n";
    
    
    
    
}